export interface LocationWeather {
    city: string;
    temperature: string;
    condition: string;
}
