export class GlobalConstants {
    public static apiURL: string = "http://api.openweathermap.org/data/2.5/";
    public static appId: string ="c51223c219d6aec8cb8c5210449bd859";
    public static units: string = "metric";
    public static countDays: string = '5';
    public static imgURL: string = 'http://openweathermap.org/img/w/';
}
